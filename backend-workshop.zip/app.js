const express = require('express');
const postRoutes = require('./routes/post.routes');

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use('/', postRoutes);

app.listen(3000, () => console.log('server run listening on port 3000'));