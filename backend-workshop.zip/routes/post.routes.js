const express = require('express');
const postControllers = require('../controllers/post.controllers');

const router = express.Router();

router.post('/post', postControllers.create);
router.get('/posts', postControllers.viewAll);
router.get('/post/:postId', postControllers.viewId);
router.put('/post/:postId', postControllers.editId);
router.delete('/post/:postId', postControllers.deleteId);
router.post('/post/:postId/reply', postControllers.replyPost);

module.exports = router;